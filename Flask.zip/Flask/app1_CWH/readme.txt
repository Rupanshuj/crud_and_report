pip install virtualenv -- run in terminal

virtualenv env -- creates an env folder for project

activating env -- .env\Scripts\activate.ps1

if error occurs then go to windows powershell and run as admin and give command :

Set-ExecutionPolicy unrestricted -- if error occurs while venv activation

------------- env\Scripts\activate.ps1 without . in beginning worked for me


---------------
Bootstrap

https://getbootstrap.com/docs/5.0/components/navbar/

Extention --> jinja2 snippet kit -- install to use jinja template