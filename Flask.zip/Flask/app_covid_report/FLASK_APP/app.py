from flask import Flask, render_template, request,  url_for
import pandas as pd
from werkzeug.utils import secure_filename
import os



app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')

@app.route('/data', methods=['GET', 'POST'])
def data():
    if request.method == 'POST':

        file = request.files['upload-file']
        type_report = request.form.get('report_type') #get value from dropdown
        print(type_report)

        if type_report == 'countrylevel':
            df = pd.read_csv(file)
            df = df.head()
            return render_template('data.html', data=df.to_html(index = False))
            ##return df.to_html() ##for postman

        if type_report == 'statelevel':
            df = pd.read_csv(file)
            df = df.groupby('State/UnionTerritory', as_index=False)['Cured'].count()
            return render_template('data.html', data=df.to_html())
 



if __name__ == '__main__':
    app.run(debug=True)
